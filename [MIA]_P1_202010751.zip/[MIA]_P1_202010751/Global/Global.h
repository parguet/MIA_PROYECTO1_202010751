//
// Created by parguet on 20/02/23.
//

#ifndef _MIA__P1_202010751_GLOBAL_H
#define _MIA__P1_202010751_GLOBAL_H
#include <iostream>
using namespace std;

struct MountedPartition {
    string name;
    string path;
    char type;
    string id;
    int start;
    int size;
    char status;
};

#endif //_MIA__P1_202010751_GLOBAL_H
