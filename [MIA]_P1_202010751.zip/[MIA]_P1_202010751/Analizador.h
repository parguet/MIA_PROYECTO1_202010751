//
// Created by parguet on 16/02/23.
//
#ifndef _MIA__P1_202010751_ANALIZADOR_H
#define _MIA__P1_202010751_ANALIZADOR_H
#include <string>
using namespace std;

class Analizador {
public:
    Analizador();
    void analizarTipo(string comando);
};


#endif //_MIA__P1_202010751_ANALIZADOR_H
