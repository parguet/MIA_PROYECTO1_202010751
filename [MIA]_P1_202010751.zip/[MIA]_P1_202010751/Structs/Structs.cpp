//
// Created by parguet on 16/02/23.
//

#include "Structs.h"
#include <string>
#include <string.h>
#include <vector>
#include <algorithm>
#include <cmath>
#include <cstring>
#include <regex>
using namespace std;
Structs::Structs(){
}